"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { FormEvent, useState } from "react";
import { api, setSession } from "@/lib/api-client";
import { Field, inputClass, btnPrimary } from "@/components/ui";

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("customer@lastmile.local");
  const [password, setPassword] = useState("password123");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const data = await api<{
        token: string;
        user: {
          id: string;
          email: string;
          name: string;
          role: "CUSTOMER" | "AGENT" | "ADMIN";
          phone?: string | null;
        };
      }>("/api/auth/login", {
        method: "POST",
        body: JSON.stringify({ email, password }),
      });
      setSession(data.token, data.user);
      if (data.user.role === "ADMIN") router.push("/admin");
      else if (data.user.role === "AGENT") router.push("/agent");
      else router.push("/customer");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Login failed");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="mx-auto flex min-h-screen max-w-md flex-col justify-center px-4">
      <Link href="/" className="font-display mb-6 text-2xl font-semibold">
        Last<span className="text-[var(--accent)]">Mile</span>
      </Link>
      <form onSubmit={onSubmit} className="panel space-y-4">
        <h1 className="text-xl font-semibold">Sign in</h1>
        <Field label="Email">
          <input
            className={inputClass}
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </Field>
        <Field label="Password">
          <input
            className={inputClass}
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </Field>
        {error && <p className="text-sm text-rose-700">{error}</p>}
        <button type="submit" className={btnPrimary} disabled={loading}>
          {loading ? "Signing in…" : "Sign in"}
        </button>
        <p className="text-sm text-[var(--muted)]">
          No account?{" "}
          <Link href="/register" className="text-[var(--accent)] underline">
            Register
          </Link>
        </p>
      </form>
    </div>
  );
}
