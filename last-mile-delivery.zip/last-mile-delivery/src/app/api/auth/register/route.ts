import { NextRequest } from "next/server";
import { Role } from "@/lib/enums";
import { prisma } from "@/lib/db";
import {
  hashPassword,
  signToken,
  jsonError,
} from "@/lib/auth";
import { registerSchema } from "@/lib/validators";

export async function POST(req: NextRequest) {
  try {
    const body = registerSchema.parse(await req.json());
    const existing = await prisma.user.findUnique({ where: { email: body.email } });
    if (existing) {
      return Response.json({ error: "Email already registered" }, { status: 409 });
    }
    const passwordHash = await hashPassword(body.password);
    const user = await prisma.user.create({
      data: {
        name: body.name,
        email: body.email.toLowerCase(),
        passwordHash,
        phone: body.phone,
        role: Role.CUSTOMER,
      },
    });
    const token = await signToken({
      sub: user.id,
      email: user.email,
      role: user.role as Role,
    });
    return Response.json({
      token,
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role as Role,
        phone: user.phone,
      },
    });
  } catch (err) {
    return jsonError(err);
  }
}
