"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { FormEvent, useState } from "react";
import { api, setSession } from "@/lib/api-client";
import { Field, inputClass, btnPrimary } from "@/components/ui";

export default function RegisterPage() {
  const router = useRouter();
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    password: "",
  });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const data = await api<{
        token: string;
        user: {
          id: string;
          email: string;
          name: string;
          role: "CUSTOMER" | "AGENT" | "ADMIN";
        };
      }>("/api/auth/register", {
        method: "POST",
        body: JSON.stringify(form),
      });
      setSession(data.token, data.user);
      router.push("/customer");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Registration failed");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="mx-auto flex min-h-screen max-w-md flex-col justify-center px-4">
      <Link href="/" className="font-display mb-6 text-2xl font-semibold">
        Last<span className="text-[var(--accent)]">Mile</span>
      </Link>
      <form onSubmit={onSubmit} className="panel space-y-4">
        <h1 className="text-xl font-semibold">Create customer account</h1>
        {(["name", "email", "phone", "password"] as const).map((key) => (
          <Field key={key} label={key[0].toUpperCase() + key.slice(1)}>
            <input
              className={inputClass}
              type={key === "password" ? "password" : key === "email" ? "email" : "text"}
              value={form[key]}
              onChange={(e) => setForm({ ...form, [key]: e.target.value })}
              required={key !== "phone"}
            />
          </Field>
        ))}
        {error && <p className="text-sm text-rose-700">{error}</p>}
        <button type="submit" className={btnPrimary} disabled={loading}>
          {loading ? "Creating…" : "Register"}
        </button>
        <p className="text-sm text-[var(--muted)]">
          Already registered?{" "}
          <Link href="/login" className="text-[var(--accent)] underline">
            Sign in
          </Link>
        </p>
      </form>
    </div>
  );
}
