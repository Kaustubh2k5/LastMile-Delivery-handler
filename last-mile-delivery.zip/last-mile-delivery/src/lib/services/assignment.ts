import { AgentStatus, OrderStatus, Role } from "@/lib/enums";
import { prisma } from "@/lib/db";
import { haversineKm } from "@/lib/geo";
import { transitionStatus } from "@/lib/services/tracking";
import { notifyStatusChange } from "@/lib/services/notifications";

export async function manualAssign(
  orderId: string,
  agentId: string,
  actorId: string,
  actorRole: Role
) {
  const agent = await prisma.user.findFirst({
    where: { id: agentId, role: Role.AGENT },
  });
  if (!agent) {
    throw Object.assign(new Error("Agent not found"), { status: 404 });
  }

  const order = await prisma.order.findUnique({ where: { id: orderId } });
  if (!order) {
    throw Object.assign(new Error("Order not found"), { status: 404 });
  }
  if (
    order.status !== OrderStatus.CREATED &&
    order.status !== OrderStatus.RESCHEDULED &&
    order.status !== OrderStatus.ASSIGNED
  ) {
    throw Object.assign(
      new Error(`Cannot assign order in status ${order.status}`),
      { status: 400 }
    );
  }

  const fromStatus = order.status;

  const updated = await prisma.$transaction(async (tx) => {
    if (order.agentId && order.agentId !== agentId) {
      await tx.user.update({
        where: { id: order.agentId },
        data: { agentStatus: AgentStatus.AVAILABLE },
      });
    }

    await tx.user.update({
      where: { id: agentId },
      data: { agentStatus: AgentStatus.BUSY },
    });

    const next = await tx.order.update({
      where: { id: orderId },
      data: { agentId, status: OrderStatus.ASSIGNED },
      include: {
        customer: true,
        agent: true,
        pickupZone: true,
        dropZone: true,
        trackingEvents: { orderBy: { createdAt: "asc" } },
      },
    });

    await tx.trackingEvent.create({
      data: {
        orderId,
        fromStatus,
        toStatus: OrderStatus.ASSIGNED,
        actorId,
        actorRole,
        note: `Manual assign to ${agent.name}`,
      },
    });

    return next;
  });

  await notifyStatusChange(updated.id, OrderStatus.ASSIGNED);
  return updated;
}

export async function autoAssign(
  orderId: string,
  actorId: string,
  actorRole: Role
) {
  const order = await prisma.order.findUnique({ where: { id: orderId } });
  if (!order) {
    throw Object.assign(new Error("Order not found"), { status: 404 });
  }
  if (
    order.status !== OrderStatus.CREATED &&
    order.status !== OrderStatus.RESCHEDULED &&
    order.status !== OrderStatus.ASSIGNED
  ) {
    throw Object.assign(
      new Error(`Cannot auto-assign order in status ${order.status}`),
      { status: 400 }
    );
  }

  const agents = await prisma.user.findMany({
    where: { role: Role.AGENT, agentStatus: AgentStatus.AVAILABLE },
  });
  if (agents.length === 0) {
    throw Object.assign(new Error("NO_AVAILABLE_AGENT"), { status: 409 });
  }

  type Scored = { id: string; name: string; score: number; reason: string };
  const scored: Scored[] = agents.map((a) => {
    if (
      order.pickupLat != null &&
      order.pickupLng != null &&
      a.currentLat != null &&
      a.currentLng != null
    ) {
      const km = haversineKm(
        a.currentLat,
        a.currentLng,
        order.pickupLat,
        order.pickupLng
      );
      return { id: a.id, name: a.name, score: km, reason: `distance ${km.toFixed(2)} km` };
    }
    // Fallback: prefer home zone match
    if (a.homeZoneId && a.homeZoneId === order.pickupZoneId) {
      return { id: a.id, name: a.name, score: 50, reason: "same home zone" };
    }
    return { id: a.id, name: a.name, score: 1000, reason: "no location fallback" };
  });

  scored.sort((a, b) => a.score - b.score);
  const best = scored[0];

  const fromStatus = order.status;

  const updated = await prisma.$transaction(async (tx) => {
    if (order.agentId && order.agentId !== best.id) {
      await tx.user.update({
        where: { id: order.agentId },
        data: { agentStatus: AgentStatus.AVAILABLE },
      });
    }

    await tx.user.update({
      where: { id: best.id },
      data: { agentStatus: AgentStatus.BUSY },
    });

    const next = await tx.order.update({
      where: { id: orderId },
      data: { agentId: best.id, status: OrderStatus.ASSIGNED },
      include: {
        customer: true,
        agent: true,
        pickupZone: true,
        dropZone: true,
        trackingEvents: { orderBy: { createdAt: "asc" } },
      },
    });

    await tx.trackingEvent.create({
      data: {
        orderId,
        fromStatus,
        toStatus: OrderStatus.ASSIGNED,
        actorId,
        actorRole,
        note: `Auto-assigned to ${best.name} (${best.reason})`,
      },
    });

    return next;
  });

  await notifyStatusChange(updated.id, OrderStatus.ASSIGNED);
  return { order: updated, assignment: best };
}

/** Used only when we need transitionStatus path without double-assign — re-export for clarity */
export { transitionStatus };
