import { NotificationChannel, NotificationStatus, OrderStatus } from "@/lib/enums";
import nodemailer from "nodemailer";
import { prisma } from "@/lib/db";

function statusLabel(s: OrderStatus) {
  return s.replace(/_/g, " ");
}

async function sendEmail(opts: {
  to: string;
  subject: string;
  body: string;
}): Promise<NotificationStatus> {
  const host = process.env.SMTP_HOST;
  const user = process.env.SMTP_USER;
  const pass = process.env.SMTP_PASS;
  const from = process.env.SMTP_FROM || "noreply@lastmile.local";

  if (!host || !user || !pass) {
    console.log(`[EMAIL STUB] To: ${opts.to} | ${opts.subject}\n${opts.body}`);
    return NotificationStatus.STUBBED;
  }

  try {
    const transporter = nodemailer.createTransport({
      host,
      port: Number(process.env.SMTP_PORT || 587),
      secure: process.env.SMTP_SECURE === "true",
      auth: { user, pass },
    });
    await transporter.sendMail({
      from,
      to: opts.to,
      subject: opts.subject,
      text: opts.body,
    });
    return NotificationStatus.SENT;
  } catch (e) {
    console.error("Email send failed", e);
    return NotificationStatus.FAILED;
  }
}

async function sendSms(opts: {
  to: string;
  body: string;
}): Promise<NotificationStatus> {
  const key = process.env.SMS_API_KEY;
  const url = process.env.SMS_API_URL;

  if (!key || !url) {
    console.log(`[SMS STUB] To: ${opts.to} | ${opts.body}`);
    return NotificationStatus.STUBBED;
  }

  try {
    // Generic free-tier compatible POST; configure SMS_API_URL to your provider.
    const res = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${key}`,
      },
      body: JSON.stringify({ to: opts.to, message: opts.body }),
    });
    if (!res.ok) return NotificationStatus.FAILED;
    return NotificationStatus.SENT;
  } catch (e) {
    console.error("SMS send failed", e);
    return NotificationStatus.FAILED;
  }
}

export async function notifyStatusChange(orderId: string, status: OrderStatus) {
  const order = await prisma.order.findUnique({
    where: { id: orderId },
    include: { customer: true },
  });
  if (!order?.customer) return;

  const subject = `Order ${order.orderNumber}: ${statusLabel(status)}`;
  const body = [
    `Hi ${order.customer.name},`,
    ``,
    `Your delivery order ${order.orderNumber} is now: ${statusLabel(status)}.`,
    `Pickup: ${order.pickupAddress} (${order.pickupPin})`,
    `Drop: ${order.dropAddress} (${order.dropPin})`,
    `Charge: ₹${order.totalCharge.toFixed(2)}`,
    status === OrderStatus.FAILED
      ? `Reason: ${order.failureReason || "n/a"}. You can reschedule from your dashboard.`
      : "",
    ``,
    `— Last-Mile Delivery Tracker`,
  ]
    .filter(Boolean)
    .join("\n");

  const emailStatus = await sendEmail({
    to: order.customer.email,
    subject,
    body,
  });

  await prisma.notificationLog.create({
    data: {
      orderId,
      channel: NotificationChannel.EMAIL,
      recipient: order.customer.email,
      subject,
      body,
      status: emailStatus,
    },
  });

  if (order.customer.phone) {
    const smsBody = `Order ${order.orderNumber}: ${statusLabel(status)}. Track in Last-Mile app.`;
    const smsStatus = await sendSms({ to: order.customer.phone, body: smsBody });
    await prisma.notificationLog.create({
      data: {
        orderId,
        channel: NotificationChannel.SMS,
        recipient: order.customer.phone,
        body: smsBody,
        status: smsStatus,
      },
    });
  }
}
