import {
  OrderStatus,
  OrderType,
  PaymentType,
  Role,
} from "@/lib/enums";
import { prisma } from "@/lib/db";
import { calculateQuote } from "@/lib/services/pricing";
import { notifyStatusChange } from "@/lib/services/notifications";

function orderNumber() {
  const ts = Date.now().toString(36).toUpperCase();
  const rand = Math.floor(Math.random() * 1000)
    .toString()
    .padStart(3, "0");
  return `LM-${ts}-${rand}`;
}

export type CreateOrderInput = {
  pickupAddress: string;
  pickupPin: string;
  pickupLat?: number | null;
  pickupLng?: number | null;
  dropAddress: string;
  dropPin: string;
  dropLat?: number | null;
  dropLng?: number | null;
  lengthCm: number;
  breadthCm: number;
  heightCm: number;
  actualWeightKg: number;
  orderType: OrderType;
  paymentType: PaymentType;
  customerId: string;
  createdById: string;
  scheduledDate?: Date | null;
};

export async function quoteOrder(input: {
  pickupPin: string;
  dropPin: string;
  lengthCm: number;
  breadthCm: number;
  heightCm: number;
  actualWeightKg: number;
  orderType: OrderType;
  paymentType: PaymentType;
}) {
  return calculateQuote(input);
}

export async function createOrder(input: CreateOrderInput) {
  const quote = await calculateQuote(input);

  const order = await prisma.$transaction(async (tx) => {
    const created = await tx.order.create({
      data: {
        orderNumber: orderNumber(),
        customerId: input.customerId,
        createdById: input.createdById,
        pickupAddress: input.pickupAddress,
        pickupPin: input.pickupPin.trim(),
        pickupLat: input.pickupLat ?? null,
        pickupLng: input.pickupLng ?? null,
        pickupZoneId: quote.pickupZone.id,
        dropAddress: input.dropAddress,
        dropPin: input.dropPin.trim(),
        dropLat: input.dropLat ?? null,
        dropLng: input.dropLng ?? null,
        dropZoneId: quote.dropZone.id,
        lengthCm: input.lengthCm,
        breadthCm: input.breadthCm,
        heightCm: input.heightCm,
        actualWeightKg: input.actualWeightKg,
        volumetricWeightKg: quote.volumetricWeightKg,
        billableWeightKg: quote.billableWeightKg,
        orderType: input.orderType,
        paymentType: input.paymentType,
        baseCharge: quote.baseCharge,
        codSurcharge: quote.codSurcharge,
        totalCharge: quote.totalCharge,
        chargeBreakdown: JSON.stringify(quote.chargeBreakdown),
        status: OrderStatus.CREATED,
        scheduledDate: input.scheduledDate ?? null,
      },
      include: {
        customer: true,
        pickupZone: true,
        dropZone: true,
        trackingEvents: true,
      },
    });

    await tx.trackingEvent.create({
      data: {
        orderId: created.id,
        fromStatus: null,
        toStatus: OrderStatus.CREATED,
        actorId: input.createdById,
        actorRole:
          input.createdById === input.customerId ? Role.CUSTOMER : Role.ADMIN,
        note: "Order created",
      },
    });

    await tx.deliveryAttempt.create({
      data: {
        orderId: created.id,
        attemptNo: 1,
        scheduledDate: input.scheduledDate ?? new Date(),
      },
    });

    return tx.order.findUniqueOrThrow({
      where: { id: created.id },
      include: {
        customer: true,
        agent: true,
        pickupZone: true,
        dropZone: true,
        trackingEvents: { orderBy: { createdAt: "asc" } },
        attempts: { orderBy: { attemptNo: "asc" } },
      },
    });
  });

  await notifyStatusChange(order.id, OrderStatus.CREATED);
  return order;
}

export async function rescheduleOrder(opts: {
  orderId: string;
  customerId: string;
  scheduledDate: Date;
  notes?: string;
  actorRole: Role;
}) {
  const order = await prisma.order.findUnique({ where: { id: opts.orderId } });
  if (!order) {
    throw Object.assign(new Error("Order not found"), { status: 404 });
  }
  if (order.customerId !== opts.customerId && opts.actorRole !== Role.ADMIN) {
    throw Object.assign(new Error("Forbidden"), { status: 403 });
  }
  if (order.status !== OrderStatus.FAILED) {
    throw Object.assign(new Error("Only FAILED orders can be rescheduled"), {
      status: 400,
    });
  }

  const attemptCount = await prisma.deliveryAttempt.count({
    where: { orderId: order.id },
  });

  const updated = await prisma.$transaction(async (tx) => {
    await tx.deliveryAttempt.create({
      data: {
        orderId: order.id,
        attemptNo: attemptCount + 1,
        scheduledDate: opts.scheduledDate,
        notes: opts.notes,
      },
    });

    await tx.trackingEvent.create({
      data: {
        orderId: order.id,
        fromStatus: OrderStatus.FAILED,
        toStatus: OrderStatus.RESCHEDULED,
        actorId: opts.customerId,
        actorRole: opts.actorRole,
        note: opts.notes || `Rescheduled for ${opts.scheduledDate.toISOString()}`,
      },
    });

    return tx.order.update({
      where: { id: order.id },
      data: {
        status: OrderStatus.RESCHEDULED,
        scheduledDate: opts.scheduledDate,
        agentId: null,
        failureReason: null,
      },
      include: {
        customer: true,
        agent: true,
        pickupZone: true,
        dropZone: true,
        trackingEvents: { orderBy: { createdAt: "asc" } },
        attempts: { orderBy: { attemptNo: "asc" } },
      },
    });
  });

  await notifyStatusChange(updated.id, OrderStatus.RESCHEDULED);
  return updated;
}
