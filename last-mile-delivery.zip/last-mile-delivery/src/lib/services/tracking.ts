import { OrderStatus, Role, AgentStatus } from "@/lib/enums";
import { prisma } from "@/lib/db";
import { notifyStatusChange } from "@/lib/services/notifications";

/** Legal transitions (LLD §6). Admin override bypasses this map. */
const ALLOWED: Record<OrderStatus, OrderStatus[]> = {
  CREATED: [OrderStatus.ASSIGNED],
  ASSIGNED: [OrderStatus.PICKED_UP, OrderStatus.FAILED],
  PICKED_UP: [OrderStatus.IN_TRANSIT, OrderStatus.FAILED],
  IN_TRANSIT: [OrderStatus.OUT_FOR_DELIVERY, OrderStatus.FAILED],
  OUT_FOR_DELIVERY: [OrderStatus.DELIVERED, OrderStatus.FAILED],
  DELIVERED: [],
  FAILED: [OrderStatus.RESCHEDULED],
  RESCHEDULED: [OrderStatus.ASSIGNED],
};

export function canTransition(
  from: OrderStatus,
  to: OrderStatus,
  override = false
) {
  if (override) return true;
  return ALLOWED[from]?.includes(to) ?? false;
}

export async function transitionStatus(opts: {
  orderId: string;
  toStatus: OrderStatus;
  actorId: string;
  actorRole: Role;
  note?: string;
  failureReason?: string;
  override?: boolean;
}) {
  const order = await prisma.order.findUnique({ where: { id: opts.orderId } });
  if (!order) {
    throw Object.assign(new Error("Order not found"), { status: 404 });
  }

  const fromStatus = order.status as OrderStatus;
  if (!canTransition(fromStatus, opts.toStatus, opts.override)) {
    throw Object.assign(
      new Error(`Illegal transition ${order.status} → ${opts.toStatus}`),
      { status: 400 }
    );
  }

  const note =
    opts.note ||
    (opts.override ? "ADMIN_OVERRIDE" : undefined) ||
    opts.failureReason;

  const updated = await prisma.$transaction(async (tx) => {
    await tx.trackingEvent.create({
      data: {
        orderId: order.id,
        fromStatus,
        toStatus: opts.toStatus,
        actorId: opts.actorId,
        actorRole: opts.actorRole,
        note,
      },
    });

    const data: {
      status: OrderStatus;
      failureReason?: string | null;
      agentId?: string | null;
    } = { status: opts.toStatus };

    if (opts.toStatus === OrderStatus.FAILED) {
      data.failureReason = opts.failureReason || opts.note || "Delivery failed";
    }
    if (opts.toStatus === OrderStatus.DELIVERED) {
      data.failureReason = null;
    }

    const next = await tx.order.update({
      where: { id: order.id },
      data,
      include: {
        customer: true,
        agent: true,
        pickupZone: true,
        dropZone: true,
        trackingEvents: { orderBy: { createdAt: "asc" } },
      },
    });

    // Agent availability side-effects
    if (order.agentId) {
      if (
        opts.toStatus === OrderStatus.DELIVERED ||
        opts.toStatus === OrderStatus.FAILED
      ) {
        await tx.user.update({
          where: { id: order.agentId },
          data: { agentStatus: AgentStatus.AVAILABLE },
        });
      }
    }

    return next;
  });

  await notifyStatusChange(updated.id, opts.toStatus);

  return updated;
}
